﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CMInternational.Startup))]
namespace CMInternational
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
