﻿using System.Web;
using System.Web.Optimization;

namespace CMInternational
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-1.12.3.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryOthers").Include(
                        "~/Scripts/jquery.counterup.min.js",
                "~/Scripts/jquery.localScroll.min.js",
                "~/Scripts/jquery.scrollTo.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/otherJs").Include(
                        "~/Scripts/waypoints.min.js",
                        "~/Scripts/gmaps.min.js",
                        "~/Scripts/backtotop.js",
                        "~/Scripts/wow.min.js", 
                        "~/Scripts/gmaps.min.js"
                        ));

            bundles.Add(new ScriptBundle("~/bundles/isotope").Include(
                "~/Scripts/isotope/min/scripts-min.js",
                
                "~/Scripts/isotope/isotope.pkgd.min.js",
                "~/Scripts/isotope/packery-mode.pkgd.min.js",
                "~/Scripts/isotope/cells-by-row.js",
                "~/Scripts/isotope/scripts.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/customJs").Include(
                "~/Scripts/main.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.min.css",
                      "~/Content/animate.min.css",
                      "~/Content/carousel.css",
                      "~/Content/font-awesome.min.css",
                      "~/Content/responsive.css",
                      "~/Content/isotope/style.css",
                "~/Content/style.css"));
        }
    }
}
